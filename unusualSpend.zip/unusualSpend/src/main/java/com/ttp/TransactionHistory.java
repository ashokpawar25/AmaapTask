package com.ttp;

import java.util.ArrayList;
import java.util.List;

public class TransactionHistory {
    List<Transaction> transactions = new ArrayList<>();

    public List<Transaction> getTransactions() {
        return transactions;
    }
}
